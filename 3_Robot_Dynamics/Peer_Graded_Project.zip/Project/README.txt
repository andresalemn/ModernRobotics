A few comments:

- The simulation didn't happen in real time, due to my computing lack of power. 
- That's whhy the videos are that long.
- If you check the code, the correct times were used. 
- I added a pdf file as well to visualize the code better.

Thanks for grading my project!